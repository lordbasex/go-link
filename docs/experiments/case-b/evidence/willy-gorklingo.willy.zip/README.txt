This is a Willy Maker project (go-link Tools).
Open it in Willy Maker (go-link.org/tools/willy-maker): "Open .zip".

project.json   the game: board, settings, levels, characters
assets/        every picture, named by its SHA-256
thumbnails/    a small picture of each level
